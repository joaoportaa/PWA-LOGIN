import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword }  from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";
import app  from "./firebase.js";

const auth = getAuth(app);
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const message = document.getElementById("message");

document.getElementById("signupBtn").addEventListener("click", async (e) => {
  try {
    await createUserWithEmailAndPassword(auth, emailInput.value, passwordInput.value);
    message.textContent = "Cadastro realizado com sucesso!";
    message.style.color = "green";
  } catch (error) {
    message.textContent = error.message;
    message.style.color = "red";
  }
});

document.getElementById("loginBtn").addEventListener("click", async (e) => {
  try {
    await signInWithEmailAndPassword(auth, emailInput.value, passwordInput.value);
    message.textContent = "Login realizado!";
    message.style.color = "green";
  } catch (error) {
    message.textContent = error.message;
    message.style.color = "red";
  }
});

