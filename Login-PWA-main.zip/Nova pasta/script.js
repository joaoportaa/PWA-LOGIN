
// LOGIN / CADASTRO usando localStorage

const emailInput = document.getElementById("email");
const passInput = document.getElementById("password");
const msg = document.getElementById("message");

document.getElementById("signupBtn").addEventListener("click", () => {
    const email = emailInput.value;
    const pass = passInput.value;

    if (!email || !pass) {
        msg.textContent = "Preencha todos os campos!";
        msg.style.color = "red";
        return;
    }

    const users = JSON.parse(localStorage.getItem("users")) || {};

    if (users[email]) {
        msg.textContent = "Usuário já cadastrado!";
        msg.style.color = "red";
        return;
    }

    users[email] = pass;
    localStorage.setItem("users", JSON.stringify(users));

    msg.textContent = "Cadastro realizado com sucesso!";
    msg.style.color = "green";
});

document.getElementById("loginBtn").addEventListener("click", () => {
    const email = emailInput.value;
    const pass = passInput.value;

    const users = JSON.parse(localStorage.getItem("users")) || {};

    if (users[email] && users[email] === pass) {
        msg.textContent = "Login efetuado!";
        msg.style.color = "green";
        localStorage.setItem("loggedUser", email);
        window.location.href = "home.html";
    } else {
        msg.textContent = "Usuário ou senha incorretos!";
        msg.style.color = "red";
    }
});
