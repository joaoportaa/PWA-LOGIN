import { initializeApp } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-analytics.js";

const firebaseConfig = {
    apiKey: "AIzaSyCEYOtW3vvkL0hwmA7cwYK6oIl2uDmx0Tc",
    authDomain: "aula-17-11-ecf40.firebaseapp.com",
    projectId: "aula-17-11-ecf40",
    storageBucket: "aula-17-11-ecf40.firebasestorage.app",
    messagingSenderId: "530541229030",
    appId: "1:530541229030:web:97078ee6c1d91df1a15c27",
    measurementId: "G-Y188H9MZH5"
  };

const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

console.log(app);

export default app;
