import{
    getAuth, 
    createUserWithEmailAndPassword as createUser
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

import app from "./firebase.js";

class Auth{ 
    #firebaseAuth;
    constructor(app){
        this.#firebaseAuth = app;
    }

 createUser(email, senha){
    createUser(this.#firebaseAuth, email, senha)
    .then((userLogged) => {
        console.log ("loga vagabundo", userLogged);
        });       
    }
}
const auth = new Auth(app);

auth.createUser("sandrobélico@ww2.com", "66677788$Aa");