import {
    auth, db,
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged,
    collection,
    addDoc,
    query,
    where,
    onSnapshot,
    deleteDoc,
    doc,
    orderBy,
    serverTimestamp
} from "./firebase-config.js";

const authSection = document.getElementById('auth-section');
const userSection = document.getElementById('user-section');
const emailEl = document.getElementById('email');
const passEl = document.getElementById('password');
const taskInput = document.getElementById('task-input');
const taskList = document.getElementById('task-list');
const welcomeMsg = document.getElementById('welcome');

let unsubscribeOps = null;


document.getElementById('btn-signin').onclick = async () => {
    try {
        await signInWithEmailAndPassword(auth, emailEl.value, passEl.value);
    } catch (e) {
        alert("Erro ao entrar: " + e.message);
    }
};


document.getElementById('btn-signout').onclick = () => signOut(auth);


onAuthStateChanged(auth, (user) => {
    if (user) {
     
        authSection.classList.add("hidden");
        userSection.classList.remove("hidden");
        welcomeMsg.textContent = "Área de Estudos";
        carregarTarefas(user.uid);
    } else {
        
        authSection.classList.remove("hidden");
        userSection.classList.add("hidden");
        taskList.innerHTML = ''; 
        if (unsubscribeOps) unsubscribeOps();
    }
});




document.getElementById('btn-add').onclick = async () => {
    const text = taskInput.value.trim();
    if (!text || !auth.currentUser) return;

    try {
        await addDoc(collection(db, "tarefas"), {
            uid: auth.currentUser.uid, 
            texto: text,
            criadoEm: serverTimestamp()
        });
        taskInput.value = "";
        taskInput.focus();
    } catch (e) {
        console.error("Erro ao salvar:", e);
        alert("Erro ao salvar tarefa. Verifique o console.");
    }
};


function carregarTarefas(userId) {
    
    const q = query(
        collection(db, "tarefas"),
        where("uid", "==", userId),
        orderBy("criadoEm", "desc")
    );

    
    unsubscribeOps = onSnapshot(q, (snapshot) => {
        taskList.innerHTML = "";
        snapshot.forEach((docSnap) => {
            renderizarTarefa(docSnap.id, docSnap.data().texto);
        });
    });
}


function renderizarTarefa(id, texto) {
    const li = document.createElement('li');
    li.className = 'task-item';
    li.innerHTML = `
        <span class="task-text">${texto}</span>
        <button class="btn-delete">Concluir</button>
    `;

    
    li.querySelector('.btn-delete').onclick = () => {
        deleteDoc(doc(db, "tarefas", id));
    };

    taskList.appendChild(li);
}